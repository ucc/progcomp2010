## Example code for usage of PYML

from Mathematica import *

## wrap the function in an expression and evaluate it
def evaluate(function):
    print "-" * 80
    expression = MathematicaExpression(function)
    print "Expression:"
    print expression
    e = m.evaluate(expression)
    print "-" * 80
    print "Result:"
    result= m.process()
    print
    print result
    print "-" * 80
    print

if __name__ == '__main__':

## Instantiate Mathematica; start the MathLink kernel
    m = Mathematica()

## Simple definition
    x = MathematicaSymbol("x")
    y = MathematicaSymbol("y")
    z = MathematicaSymbol("z")

## Simple algebra
    function = (x+1)**123/x*(x+2)**-125
    evaluate(function)

## Simple integral
    function = Integrate(Power(x,2), List(x,0,2))
    evaluate(function)

## Simple expansion
    function = Expand(Power(Plus(x,1), 2))
    evaluate(function)

## A simple vector operation using converted Numeric arrays

    aarray = Numeric.transpose(Numeric.resize(Numeric.arrayrange(9), (3,3))) + 1
    x1 = convertArray(aarray)
    barray = Numeric.resize(Numeric.arrayrange(9), (3,3))
    y1 = convertArray(barray)
    function = x1*y1
    evaluate(function)

## Plot a line approximation
    Pi = MathematicaSymbol("Pi")
    function = Plot((Sin(x)  ** x) * Pi, List(x,0,"Pi"))
    evaluate(function)

## Plot a 3D surface
    function = Plot3D(Sin(Times(x,y)),List(x,0,4),List(y,0,4))
    evaluate(function)

## Plot the eigenvalue solutions to a matrix equation
    f = MathematicaFunction("f")
    list = [[z, 1, 4], [7, z-1, -1], [3, 0, 2-z]]
    list = convertArray(list)
    function = SetDelayed(f(Pattern(z,Blank)), Eigenvalues(list))
    evaluate(function)
    function = Table(f(z),List(z,0.,3.,.1))
    evaluate(function)
    function = Plot(Evaluate(f(x)),List(x,-14,14))
    evaluate(function)



## Shut down the kernel
    m.finish()



