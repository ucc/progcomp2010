import ML
import Mathematica
import tempfile
tempfile.tempdir = "/tmp"
import string
import os

## you'll need to change this to invoke a postscript viewer on your system
GSTOOL="C:\\gstools\\gsview\\gsview32.exe"

PYMLTKFUNC=0
PYMLTKINT=1
PYMLTKREAL=2
PYMLTKSTR=3
PYMLTKSYM=4
PYMLTKERROR=5

ILLEGALPKT=      0
CALLPKT=         7
EVALUATEPKT=    13
RETURNPKT=       3
INPUTNAMEPKT=    8
ENTERTEXTPKT=   14
ENTEREXPRPKT=   15
OUTPUTNAMEPKT=   9
RETURNTEXTPKT=   4
RETURNEXPRPKT=  16
DISPLAYPKT=     11
DISPLAYENDPKT=  12
MESSAGEPKT=      5
TEXTPKT=         2
INPUTPKT=        1
INPUTSTRPKT=    21
MENUPKT=         6
SYNTAXPKT=      10
SUSPENDPKT=     17
RESUMEPKT=      18
BEGINDLGPKT=   19
ENDDLGPKT=      20
FIRSTUSERPKT=  128
LASTUSERPKT=   255


class MathematicaResponse:
    def __init__(self):
	self.displaypkt = ""
    
    
    def process(self):
	ML.Flush()
	while(1):
	    pkt = ML.NextPacket()
	    if pkt == INPUTNAMEPKT:
		MathematicaInputNamePacket().handle()
	    elif pkt == DISPLAYPKT:
		self.displaypkt = self.displaypkt + MathematicaDisplayPacket().handle()
	    elif pkt == DISPLAYENDPKT:
		MathematicaDisplayEndPacket().handle()
	    elif pkt == MESSAGEPKT:
		MathematicaMessagePacket().handle()
	    elif pkt == TEXTPKT:
		MathematicaTextPacket().handle()
	    elif pkt == RETURNTEXTPKT:
		MathematicaReturnTextPacket().handle()
	    elif pkt == RETURNPKT:
		packet = MathematicaReturnPacket()
		self.DisplayPacket()
		return packet.handle(0, None)
	    else:
		packet = MathematicaUnhandledPacket(pkt)
	    ML.NewPacket()

    def DisplayPacket(self):
	s = ""
	if self.displaypkt != "":
	    s = s + open("c:\\pyml\\header.ps").read()
	    s = s + self.displaypkt
	    s = s + open("c:\\pyml\\footer.ps").read()
	    filename = "test.eps"
	    f= open(filename, "w")
	    f.write(s)
	    f.close()
	    os.system("%s %s" % (GSTOOL, filename))

class MathematicaPacket:
    def __init__(self):
	pass

class MathematicaUnhandledPacket:
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self, pkt):
	print "Cannot handle pkt==", pkt

class MathematicaReturnPacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self, level,expr):
	next = ML.GetNext()
	if next == PYMLTKFUNC:
	    function, n = ML.GetFunction()
	    subexpr = []
	    for i in range(n):
		packet = MathematicaReturnPacket()
		packet.handle(level+1, subexpr)
	    if level == 0:
		expr = Mathematica.MathematicaExpression(Mathematica.MathematicaFunction(function,subexpr))
	    else:
		expr.append(Mathematica.MathematicaFunction(function,subexpr))

	elif next == PYMLTKSYM:
	    symbol = ML.GetSymbol()
	    if level == 0:
		expr = Mathematica.MathematicaExpression(Mathematica.MathematicaSymbol(symbol))
	    else:
		expr.append(Mathematica.MathematicaSymbol(symbol))
	    return expr
	elif next == PYMLTKSTR:
	    text = ML.GetString()
	    if level == 0:
		expr = Mathmatica.MathematicaExpression(Mathematica.MathematicaString(text))
	    else:
		expr.append(Mathematica.MathematicaString(text))
	    return expr
	elif next == PYMLTKINT:
	    integer = ML.GetInteger()
	    if level == 0:
		expr = Mathematica.MathematicaExpression(Mathematica.MathematicaInteger(integer))
	    else:
		expr.append(Mathematica.MathematicaInteger(integer))
	    return expr
	elif next == PYMLTKREAL:
	    real = ML.GetReal()
	    if level == 0:
		expr = MathematicaExpression(MathematicaReal(real))
	    else:
		expr.append(Mathematica.MathematicaReal(real))
	    return expr
	elif next == PYMLTKERROR:
	    print "error: no match"
	    expr.append(None)
	    return expr
	else:
	    print "failure to match"
	    expr.append(None)
	    return expr
	return expr

class MathematicaMessagePacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	symbol = ML.GetSymbol()
	text = ML.GetString()
	print "Message: symbol=", symbol
	print "Message: text=", text

class MathematicaTextPacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	text = ML.GetString()
	print "Text: text=", text

class MathematicaReturnTextPacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	text = ML.GetString()
	print "ReturnText: text=", text

class MathematicaInputNamePacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	text = ML.GetString()
	print "InputName: text=", text


class MathematicaDisplayPacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	text = ML.GetByteString()
	return text


class MathematicaDisplayEndPacket(MathematicaPacket):
    def __init__(self):
	MathematicaPacket.__init__(self)

    def handle(self):
	text = ML.GetString()
## 	print "DisplayEnd: text=", text
